# Your answer for Task 2: Why

Do the squirrels per Hectar have primarily the same primary fur color?
{Analyze, Attributes}


Is there a correlation between the daytime (shift) and the number of squirrels per square?
{Analyze, Attributes}