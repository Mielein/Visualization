# Your answer for Task 3: How

Question 1: 
The visualisation is bad in a sense that there are many hectars but it is showing how if there is a connection between the hectar and the fur colour of the squirrel. 

I am using a Line (Bar) as the mark. The channel colour should represent the different fur colours.
To reduce the size problem with the Hectars, one could use a filter to find the specific Hectar or the Hectar with the biggest number of a fur colour.
see Visualisierung1.png

Question 2:
We have the same problem as before. There are many hectars.The visualisation shows if all squirrels in general are more active (present to be precise) in the morning/noon or in the afternoon/evening.

I am using a line as a mark but also point to be able to read the average count better.
We can use a filter as before again to concentrate on a specific hectar.
see Visualisierung2.png
