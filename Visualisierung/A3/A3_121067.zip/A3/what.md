# Your answer for Task 1: What

Hectare Squirrel Number: Quantitative
    - 1 - 23

Primary Fur Color: Categorial
    - Gray
    - Cinnamon
    - Black

Age: Ordinal
    - Juvenile
    - Adult

Date: Quantitative 
    - 10062018 - 10202018

Shift: Ordinal
    - AM
    - PM