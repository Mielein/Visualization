## Welcome to the first exercise in tĥe visualization course

# How to do the exercise? Where are the instructions?
You can find the instructions for each exercise in the index.html. For viewing it, you have several options:
- for now, since it does not contain Javascript yet, you can simply open the file with your browser

- you can use the python command line server in this directory by calling:
    - python2.x: python -m SimpleHTTPServer 8000
    - python3.x: python3 -m http.server 8000
The webpage is then available under localhost:8000 in your browser.

- if you are using Visual Studio Code, you can install the "Live Server" extension, and launch the webpage there.

- or, finally, you can do part of the first task and use npm & snowpack to set up the development environment.
For this, follow the instructions on https://www.snowpack.dev/tutorials/getting-started (without creating a new directory, you are already in the directory, you will be working in.)

# What do I do, once I finished the tasks?
When you are finished, you remove the npm_packages folder (you can recreate it by simply calling "npm install"), zip this folder and upload it to the exercise on the Moodle page. 



